$(document).ready(function () {
  $('#miLista li').eq(0).css('color', 'red');
  $('#miLista li').eq(1).css('color', 'green');
  $('#miLista li').eq(2).css('color', 'blue');
});
